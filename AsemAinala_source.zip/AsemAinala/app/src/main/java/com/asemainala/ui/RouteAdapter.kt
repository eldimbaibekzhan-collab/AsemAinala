package com.asemainala.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.asemainala.R
import com.asemainala.model.Route

class RouteAdapter(
    private val routes: List<Route>,
    private val onToggle: (Route, Boolean) -> Unit
) : RecyclerView.Adapter<RouteAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvRouteName)
        val tvDistance: TextView = view.findViewById(R.id.tvRouteDistance)
        val cbEnabled: CheckBox = view.findViewById(R.id.cbRouteEnabled)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_route, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val route = routes[position]
        holder.tvName.text = route.name
        holder.tvDistance.text = if (route.distanceKm > 0) "${route.distanceKm} км" else "Қала іші"
        holder.cbEnabled.isChecked = route.isEnabled
        holder.cbEnabled.setOnCheckedChangeListener { _, isChecked ->
            onToggle(route, isChecked)
        }
    }

    override fun getItemCount() = routes.size
}

package com.asemainala.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.asemainala.model.RouteManager
import com.asemainala.utils.PrefsManager

class AutoClickService : AccessibilityService() {

    companion object {
        const val TAG = "AutoClickService"
        const val INDRIVE_PACKAGE = "sinet.startup.inDriver"
        var isRunning = false
        var instance: AutoClickService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: PrefsManager
    private lateinit var routeManager: RouteManager
    private var lastClickTime = 0L
    private val CLICK_COOLDOWN = 3000L // 3 секунд кідіріс

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefs = PrefsManager(this)
        routeManager = RouteManager(this)
        Log.d(TAG, "AutoClickService қосылды")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isRunning) return
        if (event == null) return

        val packageName = event.packageName?.toString() ?: return
        if (!packageName.contains("inDriver", ignoreCase = true) &&
            !packageName.contains("indrive", ignoreCase = true)) return

        // Экран өзгергенде немесе жаңа терезе ашылғанда тексер
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            handler.postDelayed({ checkForNewOrder() }, 500)
        }
    }

    private fun checkForNewOrder() {
        val root = rootInActiveWindow ?: return

        try {
            // InDrive-тағы тапсырыс мәтінін іздеу
            val allNodes = getAllNodes(root)

            for (node in allNodes) {
                val text = node.text?.toString() ?: continue

                // Маршрут атауын тексер
                val matchedRoute = routeManager.findMatchingRoute(text)
                if (matchedRoute != null) {
                    Log.d(TAG, "Маршрут табылды: $matchedRoute")
                    val currentTime = System.currentTimeMillis()
                    if (currentTime - lastClickTime > CLICK_COOLDOWN) {
                        clickOnAcceptButton(root)
                        lastClickTime = currentTime
                    }
                    break
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Қате: ${e.message}")
        }
    }

    private fun clickOnAcceptButton(root: AccessibilityNodeInfo) {
        // "Қабылдау" / "Принять" / "Accept" батырмасын іздеу
        val acceptTexts = listOf(
            "Принять", "Accept", "Қабылдау",
            "Начать работу", "Подтвердить", "ОК"
        )

        val allNodes = getAllNodes(root)
        for (node in allNodes) {
            val text = node.text?.toString() ?: continue
            if (acceptTexts.any { text.contains(it, ignoreCase = true) }) {
                if (node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    Log.d(TAG, "Батырма басылды: $text")
                    return
                }
                // Координаттар арқылы басу
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                if (!bounds.isEmpty) {
                    performClick(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                    return
                }
            }
        }
    }

    fun performClick(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)

        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(
            GestureDescription.StrokeDescription(path, 0, 100)
        )

        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Gesture орындалды: ($x, $y)")
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.d(TAG, "Gesture болдырылмады")
            }
        }, null)
    }

    private fun getAllNodes(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        nodes.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            nodes.addAll(getAllNodes(child))
        }
        return nodes
    }

    override fun onInterrupt() {
        Log.d(TAG, "Сервис үзілді")
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        instance = null
    }
}

package com.asemainala.utils

import android.content.Context
import android.content.SharedPreferences
import com.asemainala.model.Route
import org.json.JSONArray
import org.json.JSONObject

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("asemainala_prefs", Context.MODE_PRIVATE)

    companion object {
        const val KEY_ENABLED_ROUTES = "enabled_routes"
        const val KEY_CUSTOM_ROUTES = "custom_routes"
        const val KEY_SERVICE_ACTIVE = "service_active"
        const val KEY_CLICK_DELAY = "click_delay"
    }

    fun getEnabledRoutes(): Set<String> {
        return prefs.getStringSet(KEY_ENABLED_ROUTES, emptySet()) ?: emptySet()
    }

    fun saveEnabledRoutes(routes: Set<String>) {
        prefs.edit().putStringSet(KEY_ENABLED_ROUTES, routes).apply()
    }

    fun isServiceActive(): Boolean {
        return prefs.getBoolean(KEY_SERVICE_ACTIVE, false)
    }

    fun setServiceActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ACTIVE, active).apply()
    }

    fun getClickDelay(): Long {
        return prefs.getLong(KEY_CLICK_DELAY, 1000L)
    }

    fun setClickDelay(delay: Long) {
        prefs.edit().putLong(KEY_CLICK_DELAY, delay).apply()
    }

    fun addCustomRoute(name: String, distance: Int) {
        val routes = getCustomRoutes().toMutableList()
        routes.add(Route(name, distance, true))
        val json = JSONArray()
        for (r in routes) {
            val obj = JSONObject()
            obj.put("name", r.name)
            obj.put("distance", r.distanceKm)
            json.put(obj)
        }
        prefs.edit().putString(KEY_CUSTOM_ROUTES, json.toString()).apply()
    }

    fun getCustomRoutes(): List<Route> {
        val jsonStr = prefs.getString(KEY_CUSTOM_ROUTES, "[]") ?: "[]"
        val routes = mutableListOf<Route>()
        val json = JSONArray(jsonStr)
        for (i in 0 until json.length()) {
            val obj = json.getJSONObject(i)
            routes.add(
                Route(
                    name = obj.getString("name"),
                    distanceKm = obj.getInt("distance"),
                    isEnabled = true
                )
            )
        }
        return routes
    }
}

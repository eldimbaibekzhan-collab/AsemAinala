package com.asemainala.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.asemainala.R
import com.asemainala.model.Route
import com.asemainala.model.RouteManager
import com.asemainala.service.AutoClickService
import com.asemainala.utils.PrefsManager

class MainActivity : AppCompatActivity() {

    private lateinit var routeManager: RouteManager
    private lateinit var prefs: PrefsManager
    private lateinit var adapter: RouteAdapter
    private lateinit var btnToggle: Button
    private lateinit var tvStatus: TextView
    private lateinit var rvRoutes: RecyclerView
    private lateinit var btnAddRoute: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        routeManager = RouteManager(this)
        prefs = PrefsManager(this)

        initViews()
        setupRouteList()
        updateStatus()
    }

    private fun initViews() {
        btnToggle = findViewById(R.id.btnToggle)
        tvStatus = findViewById(R.id.tvStatus)
        rvRoutes = findViewById(R.id.rvRoutes)
        btnAddRoute = findViewById(R.id.btnAddRoute)

        btnToggle.setOnClickListener {
            if (!isAccessibilityEnabled()) {
                showAccessibilityDialog()
                return@setOnClickListener
            }
            toggleService()
        }

        btnAddRoute.setOnClickListener {
            showAddRouteDialog()
        }
    }

    private fun setupRouteList() {
        val routes = routeManager.getAllRoutes()
        adapter = RouteAdapter(routes) { route, enabled ->
            routeManager.saveRouteState(route.name, enabled)
        }
        rvRoutes.layoutManager = LinearLayoutManager(this)
        rvRoutes.adapter = adapter
    }

    private fun toggleService() {
        val isActive = AutoClickService.isRunning
        AutoClickService.isRunning = !isActive
        prefs.setServiceActive(!isActive)
        updateStatus()
    }

    private fun updateStatus() {
        val isActive = AutoClickService.isRunning
        if (isActive) {
            btnToggle.text = "⏹ ТОҚТАТУ"
            btnToggle.setBackgroundColor(0xFFE53935.toInt())
            tvStatus.text = "✅ Жұмыс істеуде..."
            tvStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            btnToggle.text = "▶ ІСКЕ ҚОСУ"
            btnToggle.setBackgroundColor(0xFF1565C0.toInt())
            tvStatus.text = "⏸ Тоқтатылған"
            tvStatus.setTextColor(0xFFFF9800.toInt())
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val services = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return services.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("Рұқсат қажет")
            .setMessage("Автокликер жұмыс істеуі үшін Accessibility (Арнайы мүмкіндіктер) рұқсатын беру керек.\n\nПараметрлер → Арнайы мүмкіндіктер → AsemAinala → Қосу")
            .setPositiveButton("Параметрлерге өту") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Болдырмау", null)
            .show()
    }

    private fun showAddRouteDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 30, 50, 10)
        }

        val etName = EditText(this).apply { hint = "Маршрут атауы (мыс: Қаскелең)" }
        val etDist = EditText(this).apply {
            hint = "Қашықтық (км)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        layout.addView(etName)
        layout.addView(etDist)

        AlertDialog.Builder(this)
            .setTitle("Маршрут қосу")
            .setView(layout)
            .setPositiveButton("Қосу") { _, _ ->
                val name = etName.text.toString().trim()
                val dist = etDist.text.toString().toIntOrNull() ?: 0
                if (name.isNotEmpty()) {
                    routeManager.addCustomRoute(name, dist)
                    setupRouteList()
                    Toast.makeText(this, "$name маршруты қосылды", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Болдырмау", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }
}

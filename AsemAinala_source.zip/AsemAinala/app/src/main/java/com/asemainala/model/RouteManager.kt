package com.asemainala.model

import android.content.Context
import com.asemainala.utils.PrefsManager

data class Route(
    val name: String,
    val distanceKm: Int,
    var isEnabled: Boolean = true
)

class RouteManager(private val context: Context) {

    private val prefs = PrefsManager(context)

    // Әдепкі маршруттар тізімі (суреттен алынған)
    val defaultRoutes = listOf(
        Route("Ұзынағаш", 47),
        Route("Есік", 49),
        Route("Қонаев", 75),
        Route("Қордай", 176),
        Route("Талдықорған", 235),
        Route("Үштөбе", 245),
        Route("Шу", 257),
        Route("Жамбыл", 310),
        Route("Тараз", 680),
        Route("Алматы", 0),
        // Орысша баламалары
        Route("Узунагаш", 47),
        Route("Есик", 49),
        Route("Конаев", 75),
        Route("Капчагай", 80),
        Route("Кордай", 176),
        Route("Талдыкорган", 235),
        Route("Уштобе", 245),
        Route("Жамбыл", 310)
    )

    fun getEnabledRoutes(): List<Route> {
        val saved = prefs.getEnabledRoutes()
        return defaultRoutes.map { route ->
            route.copy(isEnabled = saved.contains(route.name))
        }
    }

    fun saveRouteState(routeName: String, enabled: Boolean) {
        val current = prefs.getEnabledRoutes().toMutableSet()
        if (enabled) current.add(routeName) else current.remove(routeName)
        prefs.saveEnabledRoutes(current)
    }

    fun findMatchingRoute(text: String): String? {
        val enabledRoutes = getEnabledRoutes().filter { it.isEnabled }
        for (route in enabledRoutes) {
            if (text.contains(route.name, ignoreCase = true)) {
                return route.name
            }
        }
        return null
    }

    fun addCustomRoute(name: String, distance: Int) {
        prefs.addCustomRoute(name, distance)
    }

    fun getCustomRoutes(): List<Route> {
        return prefs.getCustomRoutes()
    }

    fun getAllRoutes(): List<Route> {
        return defaultRoutes + getCustomRoutes()
    }
}
